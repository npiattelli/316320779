const config = require('./db.config');
const mysql = require("mysql");

const conn = mysql.createConnection(config);

conn.connect();

start = () => {
    conn.query(
        `CREATE DATABASE IF NOT EXISTS web;`,
        function (err, data, fields) {
            if (err) {
                throw new Error(err.message);
            } else {
                console.log({
                    status: "success",
                    message: "database web created!",
                });
            }
        }
    );

    conn.query("USE web", function (err, results) {
        if (err) throw err;
        console.log("Selected database web");
    });

    conn.query(
        `CREATE TABLE IF NOT EXISTS web.contact_us (
            id INT NOT NULL AUTO_INCREMENT,
            fullname VARCHAR(25) NOT NULL ,
            email VARCHAR(25) NOT NULL ,
            subject VARCHAR(25) NOT NULL ,
            message VARCHAR(1000) NOT NULL ,
            PRIMARY KEY (id)
        );`,
        function (err, data, fields) {
            if (err) {
                throw new Error(err.message);
            } else {
                console.log({
                    status: "success",
                    message: "contact_us table created!",
                });
            }
        }
    );

    conn.query(
        `CREATE TABLE IF NOT EXISTS web.academies (
            id INT NOT NULL AUTO_INCREMENT,
            academy_name VARCHAR(100) NOT NULL ,
            degree VARCHAR(50) NOT NULL ,
            address VARCHAR(50) NOT NULL ,
            min_grades_avg INT NOT NULL ,
            min_psycoiteral_grade INT NOT NULL ,
            min_psycomath_grade INT NOT NULL ,
            min_psycogeneral_grade INT NOT NULL ,
            PRIMARY KEY (id)
        );`,
        function (err, data, fields) {
            if (err) {
                throw new Error(err.message);
            } else {
                console.log({
                    status: "success",
                    message: "academies table created!",
                });
            }
        }
    );

    conn.query(
        `CREATE TABLE IF NOT EXISTS web.users (
            id INT NOT NULL AUTO_INCREMENT,
            fullname VARCHAR(25) NOT NULL ,
            email VARCHAR(25) NOT NULL ,
            password VARCHAR(25) NOT NULL ,
            PRIMARY KEY (id)
        );`,
        function (err, data, fields) {
            if (err) {
                throw new Error(err.message);
            } else {
                console.log({
                    status: "success",
                    message: "users table created!",
                });
            }
        }
    );

    conn.query(`SELECT COUNT(*) as count FROM web.academies`, function (err, data, fields) {
        if (err) {
            throw new Error(err.message);
        } else {
            results = JSON.parse(JSON.stringify(data));
            if (results[0].count === 0) {
                const academies = [
                    {
                        academy_name:
                            "Technion - Israel Institute of Technology",
                        degree: "B.Sc. Biology and Chemistry",
                        address:
                            "הטכניון - מכון טכנולוגי לישראל, חיפה, 3200003",
                        min_grades_avg: 95,
                        min_psycoiteral_grade: 710,
                        min_psycomath_grade: 710,
                        min_psycogeneral_grade: 700,
                    },
                    {
                        academy_name:
                            "Technion - Israel Institute of Technology",
                        degree: "B.Sc. Chemical Engineering",
                        address:
                            "הטכניון - מכון טכנולוגי לישראל, חיפה, 3200003",
                        min_grades_avg: 90,
                        min_psycoiteral_grade: 720,
                        min_psycomath_grade: 720,
                        min_psycogeneral_grade: 720,
                    },
                    {
                        academy_name:
                            "Technion - Israel Institute of Technology",
                        degree: "B.Sc. Computer Engineering",
                        address:
                            "הטכניון - מכון טכנולוגי לישראל, חיפה, 3200003",
                        min_grades_avg: 90,
                        min_psycoiteral_grade: 710,
                        min_psycomath_grade: 710,
                        min_psycogeneral_grade: 710,
                    },
                    {
                        academy_name:
                            "Technion - Israel Institute of Technology",
                        degree: "B.Sc. Environmental Engineering",
                        address:
                            "הטכניון - מכון טכנולוגי לישראל, חיפה, 3200003",
                        min_grades_avg: 85,
                        min_psycoiteral_grade: 700,
                        min_psycomath_grade: 710,
                        min_psycogeneral_grade: 700,
                    },
                    {
                        academy_name:
                            "Technion - Israel Institute of Technology",
                        degree: "B.Sc. Landscape Architecture",
                        address:
                            "הטכניון - מכון טכנולוגי לישראל, חיפה, 3200003",
                        min_grades_avg: 85,
                        min_psycoiteral_grade: 685,
                        min_psycomath_grade: 685,
                        min_psycogeneral_grade: 685,
                    },
                    {
                        academy_name:
                            "Technion - Israel Institute of Technology",
                        degree: "B.Sc. Mathematics",
                        address:
                            "הטכניון - מכון טכנולוגי לישראל, חיפה, 3200003",
                        min_grades_avg: 100,
                        min_psycoiteral_grade: 720,
                        min_psycomath_grade: 760,
                        min_psycogeneral_grade: 720,
                    },
                    {
                        academy_name:
                            "Technion - Israel Institute of Technology",
                        degree: "B.Sc. Medicine",
                        address:
                            "הטכניון - מכון טכנולוגי לישראל, חיפה, 3200003",
                        min_grades_avg: 105,
                        min_psycoiteral_grade: 760,
                        min_psycomath_grade: 760,
                        min_psycogeneral_grade: 760,
                    },
                    {
                        academy_name:
                            "The College of Management Academic Studies",
                        degree: "B.Sc. Business Administration",
                        address: "אלי ויזל 2, ראשון לציון",
                        min_grades_avg: 80,
                        min_psycoiteral_grade: 600,
                        min_psycomath_grade: 620,
                        min_psycogeneral_grade: 600,
                    },
                    {
                        academy_name:
                            "The College of Management Academic Studies",
                        degree: "B.Sc. Computer Engineering",
                        address: "אלי ויזל 2, ראשון לציון",
                        min_grades_avg: 90,
                        min_psycoiteral_grade: 650,
                        min_psycomath_grade: 650,
                        min_psycogeneral_grade: 650,
                    },
                    {
                        academy_name: "Sapir College",
                        degree: "B.Sc. Cultural Studies, Creativity and Production",
                        address: "כביש 232 מ.א. שער הנגב, 7956000",
                        min_grades_avg: 95,
                        min_psycoiteral_grade: 620,
                        min_psycomath_grade: 620,
                        min_psycogeneral_grade: 620,
                    },
                    {
                        academy_name: "Sapir College",
                        degree: "B.Sc. Economics & Accounting",
                        address: "כביש 232 מ.א. שער הנגב, 7956000",
                        min_grades_avg: 95,
                        min_psycoiteral_grade: 585,
                        min_psycomath_grade: 585,
                        min_psycogeneral_grade: 585,
                    },
                    {
                        academy_name: "Sapir College",
                        degree: "B.Sc. Social Work",
                        address: "כביש 232 מ.א. שער הנגב, 7956000",
                        min_grades_avg: 80,
                        min_psycoiteral_grade: 545,
                        min_psycomath_grade: 545,
                        min_psycogeneral_grade: 545,
                    },
                    {
                        academy_name: "Tel Aviv University",
                        degree: "B.Sc. Biology and Chemistry",
                        address: "אוניברסיטת תל-אביב, תל אביב-יפו",
                        min_grades_avg: 95,
                        min_psycoiteral_grade: 700,
                        min_psycomath_grade: 700,
                        min_psycogeneral_grade: 700,
                    },
                    {
                        academy_name: "Tel Aviv University",
                        degree: "B.Sc. Chemical Engineering",
                        address: "אוניברסיטת תל-אביב, תל אביב-יפו",
                        min_grades_avg: 90,
                        min_psycoiteral_grade: 700,
                        min_psycomath_grade: 700,
                        min_psycogeneral_grade: 700,
                    },
                    {
                        academy_name: "Tel Aviv University",
                        degree: "B.Sc. Computer Engineering",
                        address: "אוניברסיטת תל-אביב, תל אביב-יפו",
                        min_grades_avg: 85,
                        min_psycoiteral_grade: 700,
                        min_psycomath_grade: 700,
                        min_psycogeneral_grade: 700,
                    },
                    {
                        academy_name: "Tel Aviv University",
                        degree: "B.Sc. Environmental Engineering",
                        address: "אוניברסיטת תל-אביב, תל אביב-יפו",
                        min_grades_avg: 80,
                        min_psycoiteral_grade: 700,
                        min_psycomath_grade: 710,
                        min_psycogeneral_grade: 700,
                    },
                    {
                        academy_name: "Tel Aviv University",
                        degree: "B.Sc. Landscape Architecture",
                        address: "אוניברסיטת תל-אביב, תל אביב-יפו",
                        min_grades_avg: 80,
                        min_psycoiteral_grade: 665,
                        min_psycomath_grade: 665,
                        min_psycogeneral_grade: 665,
                    },
                    {
                        academy_name: "Tel Aviv University",
                        degree: "B.Sc. Mathematics",
                        address: "אוניברסיטת תל-אביב, תל אביב-יפו",
                        min_grades_avg: 90,
                        min_psycoiteral_grade: 710,
                        min_psycomath_grade: 710,
                        min_psycogeneral_grade: 710,
                    },
                    {
                        academy_name: "Tel Aviv University",
                        degree: "B.Sc. Medicine",
                        address: "אוניברסיטת תל-אביב, תל אביב-יפו",
                        min_grades_avg: 100,
                        min_psycoiteral_grade: 730,
                        min_psycomath_grade: 730,
                        min_psycogeneral_grade: 730,
                    },
                ];

                for (let i = 0; i < academies.length; i++) {
                    const academy = academies[i];
                    conn.query(
                        `INSERT INTO web.academies (id, academy_name, degree, address, min_grades_avg, min_psycoiteral_grade, min_psycomath_grade, min_psycogeneral_grade)
                        VALUES (${i + 1}, '${academy.academy_name}', '${academy.degree}', '${academy.address}', '${academy.min_grades_avg}', '${academy.min_psycoiteral_grade}', '${academy.min_psycomath_grade}', '${academy.min_psycogeneral_grade}')`,
                        function (err, data, fields) {
                            if (err) {
                                throw new Error(err.message);
                            } else {
                                console.log({
                                    status: "success",
                                    message: `academy ${academy.academy_name} created!`,
                                });
                            }
                        }
                    );
                }
            }
        }
    });

    conn.query(`SELECT COUNT(*) as count FROM web.users`, function (err, data, fields) {
        if (err) {
            throw new Error(err.message);
        } else {
            results = JSON.parse(JSON.stringify(data));
            if (results[0].count === 0) {
                for (let i = 1; i <= 3; i++) {
                    conn.query(
                        `INSERT INTO web.users (id, fullname, email, password)
                        VALUES (${i}, 'user${i}', 'user${i}@gmail.com', '123456')`,
                        function (err, data, fields) {
                            if (err) {
                                throw new Error(err.message);
                            } else {
                                console.log({
                                    status: "success",
                                    message: `user${i} created!`,
                                });
                            }
                        }
                    );
                }
            }
        }
    });
}

module.exports = { conn, start };