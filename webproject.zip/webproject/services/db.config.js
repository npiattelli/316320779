const config = {
    host: "localhost",
    user: "root",
    password: "",
    database: "web",
};

module.exports = config;