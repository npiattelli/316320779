const { conn } = require("../services/db");

exports.signIn = (req, res) => {
    const { email, password } = req.body;
    conn.query("SELECT * FROM `web`.`users` WHERE `email` = '" + email + "' AND `password` = '" + password + "' LIMIT 1",
    function (err, data, fields) {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.status(200).json({
                data,
                status: "success",
                length: data?.length,
            });
        }
    });
};

exports.findUserByEmail = (req, res) => {
    conn.query("SELECT * FROM `web`.`users` WHERE `email` = '" + req.query.email + "'",
        function (err, data, fields) {
            if (err) {
                res.status(500).json({
                    error: err.message
                });
            } else {
                res.status(200).json({
                    status: data?.length > 0 ? "userExist" : "userNotExist",
                });
            }
        }
    );
};

exports.signUp = (req, res) => {
    if (!req.body) {
        res.status(404).json({ error: "No form data found" });
    } else {
        conn.query(
            `INSERT INTO \`web\`.\`users\`(\`fullname\`, \`email\`, \`password\`) 
            VALUES ('${req.body.fullname}', '${req.body.email}', '${req.body.password}')`,
            function (err, mysqlres) {
                if (err) {
                    res.status(500).json({ error: err.message });
                } else {
                    res.status(201).json({
                        status: "success",
                        message: "user created!",
                    });
                }
            }
        );
    }
};

exports.contactUs = (req, res, next) => {
    conn.query(
        `INSERT INTO \`web\`.\`contact_us\`(\`fullname\`, \`email\`, \`subject\`, \`message\`) 
        VALUES ('${req.body.fullname}', '${req.body.email}', '${req.body.subject}', '${req.body.message}')`,
        function (err, fields) {
            if (err) {
                res.status(500).json({ error: err.message });
            } else {
                res.redirect(
                    "/login page.html?message=success! we received your message successfully"
                );
            }
        }
    );
};

exports.searchAcademies = (req, res) => {
    let gradesAvg = 0, scores = 0;
    const { grades, psicometricGrades } = req.body;

    for (let i = 0; i < grades.length; i++) {
        const grade = grades[i];
        let finalScore = grade.grade;
        //הבונוס ניתן רק מציון 60 ומעלה.
        if (grade.units === 4 && grade.grade >= 60) {
            //במקצועות המתמטיקה והאנגלית חישוב הבונוסים שונה, בהיקף של 4 יח”ל – תוספת של 15 נקודות לציון הסופי
            if (["Math", "English"].includes(grade.subject)) {
                finalScore += 15;
            } else {
                //למקצוע שנלמד בהיקף של 4 יח”ל – תוספת של 10 נקודות לציון הסופי.
                finalScore += 10;
            }
        }
        else if (grade.units === 5 && grade.grade >= 60) {
            if (["Math", "English"].includes(grade.subject)) {
                //במקצועות המתמטיקה והאנגלית חישוב הבונוסים שונה, בהיקף של 5 יח”ל – תוספת של 25 נקודות לציון הסופי
                finalScore += 25;
            } else {
                //למקצוע שנלמד בהיקף של 5 יח”ל – תוספת של 20 נקודות לציון הסופי
                finalScore += 20;
            }
        }
        scores += finalScore;
    }
    gradesAvg = scores / grades.length;

    conn.query(
        `SELECT * FROM web.academies WHERE min_grades_avg <= ${gradesAvg} 
        AND min_psycoiteral_grade <= ${psicometricGrades.psycoiteral} 
        AND min_psycomath_grade <= ${psicometricGrades.psycomath} 
        AND min_psycogeneral_grade <= ${psicometricGrades.psycogeneral}`,
        function (err, data, fields) {
            if (err) {
                res.status(500).json({
                    error: err.message,
                });
            } else {
                res.status(200).json({
                    data,
                    status: "success",
                    length: data?.length,
                });
            }
        }
    );
};