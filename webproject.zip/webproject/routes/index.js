const express = require("express");
const controllers = require("../controllers");
const router = express.Router();

router
    .route("/api/signIn")
    .post(controllers.signIn);

router
    .route("/api/signUp")
    .post(controllers.signUp);

router
    .route("/api/users/search")
    .get(controllers.findUserByEmail)

router
    .route("/api/contact-us")
    .post(controllers.contactUs)

router
    .route("/api/searchAcademies")
    .post(controllers.searchAcademies)

module.exports = router;