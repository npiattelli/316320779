function signIn(event) {
    event.preventDefault();
    const emailelem = document.getElementById("email");
    const passwordelem = document.getElementById("password");

    if (emailelem.value && passwordelem.value) {
        fetch(`http://localhost:3000/api/signIn`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                email: emailelem.value,
                password: passwordelem.value,
            }),
        })
            .then((response) => response.json())
            .then((response) => {
                if (response.data?.length > 0) {
                    const user = response.data[0];
                    sessionStorage.setItem(
                        "LOGGED_IN_USER",
                        JSON.stringify(user)
                    );
                    window.location = "index.html";
                } else {
                    alert("No user was found for the given email & password!");
                }
            })
            .catch((e) => {
                console.log(e);
                alert("A server error occurred");
            });
    } else {
        alert("Email & password are required!");
    }
}

async function signUp(event) {
    event.preventDefault();

    const fullnameelem = document.getElementById("fullname");
    const emailelem = document.getElementById("email");
    const passwordelem = document.getElementById("password");

    if (signupValid(fullnameelem.value, emailelem.value, passwordelem.value)) {
        fetch(`http://localhost:3000/api/signUp`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                fullname: fullnameelem.value,
                email: emailelem.value,
                password: passwordelem.value,
            }),
        })
            .then((response) => response.json())
            .then((response) => {
                if (response.status === "success") {
                    window.location = "login page.html";
                } else {
                    alert("Error while creating new user!");
                }
            })
            .catch((e) => {
                console.log(e);
                alert("A server error occurred");
            });
    }
}

// check if there is a user registerd with that email already
async function signupValid(fullname, email, password) {
    if (fullname && email && password) {
        return true;
    }
    // check if email already exist in server
    const response = await fetch(`http://localhost:3000/api/users/search?email=${email}`, { method: "GET" });
    const json = await response.json();
    return json.status === "userNotExist";
}

//add and remove row in the user page when saves grades and subjects//
function addRows() {
    let table = document.getElementById("emptbl");
    let rowCount = table.rows.length;
    let cellCount = table.rows[0].cells.length;
    let row = table.insertRow(rowCount);
    for (let i = 0; i < cellCount; i++) {
        let cell = "cell" + i;
        cell = row.insertCell(i);
        cell.innerHTML = document.getElementById("col" + i)?.innerHTML;
    }
}

function deleteRows() {
    let table = document.getElementById("emptbl");
    let rowCount = table.rows.length;
    if (rowCount > "2") {
        let row = table.deleteRow(rowCount - 1);
        rowCount--;
    } else {
        alert("There should be at least one row");
    }
}

////////////////////////////////////////////////////////

//password requirments////////////////

let myInput = document.getElementById("password");
let letter = document.getElementById("letter");
let capital = document.getElementById("capital");
let number = document.getElementById("number");
let length = document.getElementById("length");

if (myInput) {
    // When the user clicks on the password field, show the message box
    myInput.onfocus = function () {
        document.getElementById("message").style.display = "block";
    };
    
    // When the user clicks outside of the password field, hide the message box
    myInput.onblur = function () {
        document.getElementById("message").style.display = "none";
    };
    
    // When the user starts to type something inside the password field
    myInput.onkeyup = function () {
        // Validate lowercase letters
        let lowerCaseLetters = /[a-z]/g;
        if (myInput.value.match(lowerCaseLetters)) {
            letter.classList.remove("invalid");
            letter.classList.add("valid");
        } else {
            letter.classList.remove("valid");
            letter.classList.add("invalid");
        }
    
        // Validate capital letters
        let upperCaseLetters = /[A-Z]/g;
        if (myInput.value.match(upperCaseLetters)) {
            capital.classList.remove("invalid");
            capital.classList.add("valid");
        } else {
            capital.classList.remove("valid");
            capital.classList.add("invalid");
        }
    
        // Validate numbers
        let numbers = /[0-9]/g;
        if (myInput.value.match(numbers)) {
            number.classList.remove("invalid");
            number.classList.add("valid");
        } else {
            number.classList.remove("valid");
            number.classList.add("invalid");
        }
    
        // Validate length
        if (myInput.value.length >= 8) {
            length.classList.remove("invalid");
            length.classList.add("valid");
        } else {
            length.classList.remove("valid");
            length.classList.add("invalid");
        }
    };
    //password requirments////////////////
}


const params = new Proxy(new URLSearchParams(window.location.search), {
  get: (searchParams, prop) => searchParams.get(prop),
});

let message = params.message;
if (message) {
    alert(message);
    window.history.pushState({}, document.title, window.location.pathname);
}

async function search(event) {
    event.preventDefault();

    let grades = [];
    const gradeTbl = document.getElementById("emptbl");
    const rows = gradeTbl.querySelectorAll("tr");

    for (let i = 1; i < rows.length; i++) {
        const row = {
            grade: +rows[i].querySelector(".savegrade")?.value,
            units: +rows[i].querySelector(".savepoints")?.value,
            subject: rows[i].querySelector(".savesubjects")?.value,
        };
        grades.push(row);
    }

    const filterdGrades = grades.filter((g) => !!g.grade && !!g.units && !!g.subject);
    if (filterdGrades.length == 0) {
        alert('you must fill at least one grade!');
        return;
    }
    console.log(filterdGrades);

    const psicometricGrades = {
        psycoiteral: +document.getElementById("psycoiteral").value,
        psycomath: +document.getElementById("psycomath").value,
        psycogeneral: +document.getElementById("psycogeneral").value,
    };

    fetch(`http://localhost:3000/api/searchAcademies`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            grades: filterdGrades,
            psicometricGrades
        }),
    })
        .then((response) => response.json())
        .then(response => {
            if (response.length > 0) {
                sessionStorage.setItem("ACADEMIES", JSON.stringify(response.data));
                window.location = "results.html";
            }
        })
        .catch((e) => {
            console.log(e);
            alert("A server error occurred");
        });
}